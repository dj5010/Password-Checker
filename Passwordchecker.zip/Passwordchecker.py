import re

def password_strength(password):
    length = len(password)

    lower = bool(re.search(r'[a-z]', password))
    upper = bool(re.search(r'[A-Z]', password))
    digit = bool(re.search(r'\d', password))
    special = bool(re.search(r'[!@#$%^&*(),.?":{}|<>]', password))

    score = sum([lower, upper, digit, special])

    if length >= 12 and score == 4:
        return "Very Strong"
    elif length >= 10 and score >= 3:
        return "Strong"
    elif length >= 8 and score >= 2:
        return "Moderate"
    elif length >= 6:
        return "Weak"
    else:
        return "Very Weak"

def main():
    password = input("Enter your password: ")
    strength = password_strength(password)
    print(f"Password Strength: {strength}")

if __name__ == "__main__":
    main()
# Example enhancement to main():
def main():
    password = input("Enter your password: ")
    strength = password_strength(password)
    print(f"Password Strength: {strength}")

    if strength in ["Weak", "Very Weak", "Moderate"]:
        print("Consider improving your password by adding uppercase letters, numbers, or symbols.")
